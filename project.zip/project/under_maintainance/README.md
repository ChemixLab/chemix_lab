chemix_lab - Contribution

chemix_lab Project is a open source software projects helping further Chemical science on the web from both the Science Lab and the broader community. Part of the chemix_lab’s mission is to work with other community members to work collaboratively on projects that move science on the web forward. This pilot will test out ways to better communicate and facilitate means for others to get involved in a wide variety ideas, 


Collaboration

how to submit your project?

When you find a project you're interested in, just click the 'Join Project!' button to begin. The project lead will be notified and you can work together to see where your skills can help the project.

what do we expect for  chemix_lab?
As for the name chemix_lab is a virtual chemistry laboratory. therefore you all can come up with any chemistry related simulation that visually and technically attractive and useful for the students all around the world . for an example : organic structures and physical chemistry outcomes .
good luck friends ..


Compatibility targets: IE 9+, FF 3.6+, Chrome 14+, Android 2.2+, Safari 3.0+
